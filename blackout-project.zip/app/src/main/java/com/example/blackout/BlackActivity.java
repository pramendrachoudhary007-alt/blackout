package com.example.blackout;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowManager;

public class BlackActivity extends Activity {

    @Override
    @SuppressWarnings("deprecation")
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        DevicePolicyManager dpm = getSystemService(DevicePolicyManager.class);
        ComponentName admin = new ComponentName(this, AdminReceiver.class);

        if (!dpm.isDeviceOwnerApp(getPackageName())) {
            finish();   // not set up as device owner, do nothing
            return;
        }

        SharedPreferences p = getSharedPreferences("p", MODE_PRIVATE);
        long now = System.currentTimeMillis();
        long end = p.getLong("end", 0L);
        if (end == 0L) {
            int minutes = getIntent().getIntExtra("minutes", 30);
            end = now + minutes * 60L * 1000L;
            p.edit().putLong("end", end).apply();
        }
        long left = end - now;
        if (left <= 0) {
            Release.run(this, this);
            finishAndRemoveTask();
            return;
        }

        dpm.setLockTaskPackages(admin, new String[]{getPackageName()});
        dpm.setLockTaskFeatures(admin, DevicePolicyManager.LOCK_TASK_FEATURE_NONE);
        try { dpm.setKeyguardDisabled(admin, true); } catch (Exception ignored) {}

        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = 0.01f;
        getWindow().setAttributes(lp);

        View v = getWindow().getDecorView();
        v.setBackgroundColor(Color.BLACK);
        v.setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

        startLockTask();

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            Release.run(BlackActivity.this, BlackActivity.this);
            finishAndRemoveTask();
        }, left);
    }
}
